import numpy as np
import cv2 as cv
import matplotlib.pyplot as mpl_plt
import time

#############################################################
# A klaszterek számának megváltoztatása: 65. sor, paraméter #
# A bemeneti kép megváltoztatása: 59. sor, paraméter        #
#                                                           #
# To change number of clusters: Line 65, in parameter       #
# To change input image: Line 59., in parameter             #
#############################################################


class KMeans:
    def __init__(self, k):
        self.k = k
        self.centroid = None

    def KMeans_Clustering(self, pixels, max_iter=1000):
        t_start = time.time()
# 1.
        self.centroid = np.random.uniform(np.amin(pixels, axis=0), np.amax(pixels, axis=0), size=(self.k, pixels.shape[1]))

# 2.
        for _ in range(max_iter):
            y = []
            for data_point in pixels:
                euclidean_dist = np.sqrt(np.sum(np.square(self.centroid - data_point), axis=1))
                cluster_label = np.argmin(euclidean_dist)
                y.append(cluster_label)
            y = np.array(y)

# 3.
            cluster_idx = []
            for i in range(self.k):
                cluster_idx.append(np.argwhere(y == i))

# 4.
            cluster_centre = []
            for i, idx in enumerate(cluster_idx):
                if len(idx) == 0:
                    cluster_centre.append(self.centroid[i])
                else:
                    cluster_centre.append(np.mean(pixels[idx], axis=0)[0])

# 5.
            cluster_centre = np.array(cluster_centre)

            if np.linalg.norm(self.centroid - cluster_centre) < 0.001:
                break
            else:
                self.centroid = cluster_centre
        t_end = time.time()
        print("Time taken to find solution for ",self.k," centroids: ", t_end - t_start)
        return y

# OpenCV kép inicializálása, hogy a KMeans algoritmus tudja használni
image = cv.imread('image.png')
image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
pixel_values = image.reshape((-1, 3))
pixel_values = np.float32(pixel_values)

# KMeans lefuttatása, labelsben a visszatérési érték eltárolása
kmeans = KMeans(k=3)
labels = kmeans.KMeans_Clustering(pixel_values)
labels = labels.astype(int)
centers = kmeans.centroid.astype(int)

# matplotlib ábrázolás
segmented_image = centers[labels]
segmented_image = segmented_image.reshape(image.shape)
mpl_plt.figure(figsize=(10, 5))
mpl_plt.subplot(1, 2, 1)
mpl_plt.title('Original Image')
mpl_plt.imshow(image)
mpl_plt.axis('off')
mpl_plt.subplot(1, 2, 2)
mpl_plt.title('Segmented Image')
mpl_plt.imshow(segmented_image)
mpl_plt.axis('off')
mpl_plt.show()
